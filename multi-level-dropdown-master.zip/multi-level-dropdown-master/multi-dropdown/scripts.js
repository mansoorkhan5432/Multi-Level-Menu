//Create function to select elements

//Open and close nav on click